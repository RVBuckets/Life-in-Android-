package com.example.n01202172.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {
    EditText edttxt;
    CheckBox chckbx;
    Button btn;
    SharedPreferences shrdpref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

       edttxt = findViewById(R.id.editText);
       chckbx = findViewById(R.id.checkBox);
        btn = findViewById(R.id.button);
        shrdpref = this.getPreferences(Context.MODE_PRIVATE);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Method where your editing is saved. Define this method after finishing onclicklistener
                saveSharedPreference();
            }
        });
        loadPreference();  //This method is used to load ur saved text back to this usedr actvity when u return back from main activity!!

    }

    private void saveSharedPreference(){
        // Save editted work
        if(chckbx.isChecked()) {

            SharedPreferences.Editor editor = shrdpref.edit();
            editor.putString("Username",edttxt.getText().toString());
            editor.putBoolean("CheckBox",chckbx.isChecked());
            editor.commit(); // Save Preference

        }

        backToHome();
    }
    private void loadPreference() {
        // Load Saved work
        Boolean checked = shrdpref.getBoolean("CheckBox", false);
        String password = shrdpref.getString("Password", "");
        edttxt.setText(password);
        chckbx.setChecked(checked);
    }


    private void backToHome(){

        finish();
    }

}
