package com.example.n01202172.myapplication;

public class Database {
    public String temperature;
    public Database() {

    }

    public Database(String temperature){

        this.temperature = temperature;


    }
    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

}
