package com.example.n01202172.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
        actionBar.setDisplayHomeAsUpEnabled(true);

        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });

        processData();

    }


    public void processData()
    {
        // TODO: Step 9. Get the data and display here. Finished
        Bundle extras = getIntent().getExtras();

        String value1 = extras.getString("EXTRA_MESSAGE");
        if (value1 != null) { // do something with the data
            TextView mTextMessage = (TextView) findViewById(R.id.textView3);
            mTextMessage.setText(value1);

        }
    }

}








